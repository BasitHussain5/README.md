from project import check_correct_args, select_house, select_grade
import pytest

def test_check_correct_args():
    with pytest.raises(SystemExit):
        check_correct_args()



def test_select_department():
    assert select_department("CSE110") == "Department of Computer Sceince"
    assert select_department("MAT110)== Department of Mthematics and Natural Sciences"
    assert select_department("BUS101") == "Department of Bussiness Administration and management"
    assert select_department("EEE201") == "Department ogf Electric Engineering"


def test_select_grade():
    assert selec_grade(2005) == "Grade 12"
    assert selec_grade(2015) == "Grade 2"
