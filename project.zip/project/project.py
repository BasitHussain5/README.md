import sys
import csv

def main():
    check_correct_args()
    data = []
    try:
        with open(sys.argv[1]) as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                data.append(row)
    except FileNotFoundError:
        sys.exit("could't read csv file")

    output = []
    for row in data:
        department = select_department(row["courses"])
        grade = select_grade(row["birthdate"])
        output.append({"name": row["name"], "department": department, "grade": grade})

    with open(sys.argv[2], "w") as file:
        writer = csv.DictWriter(file, fieldnames=["name", "department", "grade"])
        writer.writerow({"name": "name", "department": "department", "grade": "grade"})
        for row in output:
            writer.writerow({"name": row["name"], "department": row["department"], "grade": row["grade"]})


def check_correct_args():
    if len(sys.argv) < 3:
        sys.exit("Too few command-line arguments")
    if len(sys.argv) > 3:
        sys.exit("Too many command-line arguments")
    if ".csv" not in sys.argv[1] or ".csv" not in sys.argv[2]:
        sys.exit("Not csv files")


def select_department(char):
    if char in ["CSE110", "CSE111", "CSE220"]:
        return "Department of Data Sceince"
    if char in ["MAT110", "MAT220", "MAT215"]:
        return "Department of Mthematics and Natural Sciences"
    if char in ["BUS101", "BUS201", "BUS120"]:
        return "Department of Bussiness Administration and management"
    elif char in ["EEE201", "EEE111", "EEE301"]:
        return "Department of Electric Engineering"
    else:
        return "NO Department"


def select_grade(year):
    age = 2022 - int(year)
    grade = age - 5
    return "Grade " + str(grade)



if __name__ == "__main__":
    main()